﻿using System;

namespace MyInvoice
{
    enum ProductType
    {
        Food,
        NonFood,
        Services
    }
}
