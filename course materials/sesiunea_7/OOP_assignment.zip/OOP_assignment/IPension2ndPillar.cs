﻿using System;
namespace OOP_assignment
{
    interface IPension2ndPillar
    {
        double GrossSalary { get; set; }
        void ChecktMonthlyPensionDeposit ();
    }
}

