﻿using System;
namespace OOP_assignment
{
    public class Bank
    {
        public static int NoOfCustomers { get; set; }
        public static decimal BankBalance { get; set; } = 1000000000;
    }
}

